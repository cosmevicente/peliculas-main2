<footer>
    piede de página del sitio
</footer>