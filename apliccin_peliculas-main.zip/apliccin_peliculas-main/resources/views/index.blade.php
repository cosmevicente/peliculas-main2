@extends('modelo.plantilla')

@section('title', 'Página de inicio')

@section('content')
    <h1>Bienvenidos a la página de inicio</h1>
@endsection
 