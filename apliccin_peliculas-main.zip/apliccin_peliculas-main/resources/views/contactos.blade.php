@extends('modelo.plantilla')

@section('title', 'Página de Conctactos')

@section('content')
    <h1>Contactos Peliculas</h1>
@endsection